package common

import (
	_ "github.com/tailscale/depaware/depaware"
)
