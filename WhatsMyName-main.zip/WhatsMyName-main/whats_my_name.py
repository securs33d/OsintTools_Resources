#!/usr/bin/python
from whatsmyname.main import check_for_presence

if __name__ == "__main__":
    # execute only if run as a script
    check_for_presence()
