#!/usr/bin/python
from whatsmyname.main import validate_whats_my_name

if __name__ == "__main__":
    # execute only if run as a script
    validate_whats_my_name()
